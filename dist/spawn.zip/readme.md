20170412

Not much to say about this one. Pass it a command line and that app is launched with the minimize flags set.

Not a very complex tool, but I use it a fair bit for scheduled tasks.
